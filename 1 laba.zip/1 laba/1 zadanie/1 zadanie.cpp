﻿#include <cstdlib>
#include <iostream>

// Разрешаем в данной программе пространство имен std
using namespace std;

double processArray(int arr[], size_t m, int brr[], double a1, double d)
{
    for (size_t i = 0; i < m; i++) // Считаем в цикле for арифмитическую прогрессию
    {
        arr[i] += a1;
        a1 += d;
        
    }
    int cnt = 0;

    for (size_t i = 0; i < m; ++i)
    {
        if(arr[i] >= 10 && arr[i] <= 99)
        {
            cnt++;
        }
    }

    int k = 0;
    for(size_t i = 0; i < m; ++i)
    {
        int a = arr[i] / 10;
        int b = arr[i] % 10;
        int c = a + b;
        if (c != 10)
        {
            brr[k] = arr[i];
            k++;
        }
    }

    return cnt;
}

void printArray_a(int* arr, size_t m)
{
    for (size_t i = 0; i < m; ++i)
    {
        cout << arr[i] << "  ";
    }
    printf("\n");
    printf("\n");
}

void printArray_b(int* brr, size_t m)
{
    puts("Выход: ");
    for (size_t i = 0; i < m; ++i)
    {
        cout << brr[i] << "  ";
    }
    printf("\n");
}

int main()
{
    setlocale(LC_ALL, "RUS");   // Добавили кириллицу для нормального отображения запроса
    const size_t M = 15;    // Размер массива равен 15 (По здаанию)
    double a1, d;  // Объявление нужных для нас переменных
    
    cin >> a1 >> d;

    int a[M] = { 0 };  // Создаем массив и инциализируем нулями
    int b[M] = { 0 };  // Создаем массив и инциализируем нулями

    // Подсчет арифмитической прогрессии, а также возвращение только двухзначных чисел
    double result = processArray(a, M, b, a1, d);

    // Вывод массивов на экран
    printArray_a(a, M);
    printArray_b(b, M);

    // ... и количество двухзначных чисел
    printf("cnt: %g\n\n", result);

    return 0;
}
